# This file makes 'templatetags' a Python package so Django can discover custom template tags.
