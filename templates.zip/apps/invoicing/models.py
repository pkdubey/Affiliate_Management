# Updated models.py - Fixed to work with your existing structure
from django.db import models
from decimal import Decimal, ROUND_HALF_UP

class Invoice(models.Model):
    CURRENCY_CHOICES = [
        ('USD', 'USD'),
        ('EUR', 'EUR'),
        ('INR', 'INR'),
    ]
    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Paid', 'Paid'),
        ('Cancelled', 'Cancelled'),
        ('Overdue', 'Overdue'),
    ]
    PARTY_TYPE_CHOICES = [
        ('publisher', 'Publisher'),
        ('advertiser', 'Advertiser'),
    ]

    # Basic Invoice Information
    date = models.DateField(auto_now_add=True)  # Changed to auto_now_add for current date
    invoice_number = models.CharField(max_length=100, unique=True, blank=True)  # Made unique and blank for auto-generation
    due_date = models.DateField()
    party_type = models.CharField(max_length=16, choices=PARTY_TYPE_CHOICES, default='publisher')
    
    # Relationships
    publisher = models.ForeignKey('publishers.Publisher', on_delete=models.CASCADE, blank=True, null=True)
    advertiser = models.ForeignKey('advertisers.Advertiser', on_delete=models.CASCADE, blank=True, null=True)
    drs = models.ForeignKey('drs.DailyRevenueSheet', on_delete=models.CASCADE, blank=True, null=True)

    # EXISTING FIELDS (keeping for backward compatibility)
    bill_from_details = models.TextField(blank=True, null=True)
    bill_to_details = models.TextField(blank=True, null=True)
    bank_details = models.TextField(blank=True, null=True)
    terms = models.TextField(blank=True, null=True, default="Thanks for your business.")
    signature = models.ImageField(upload_to="invoices/signatures/", blank=True, null=True)

    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Pending')
    currency = models.CharField(max_length=3, choices=CURRENCY_CHOICES, default='USD')
    amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    gst_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    total_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    pdf = models.FileField(upload_to='invoices/pdf/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    # NEW STRUCTURED FIELDS (adding to existing structure)
    # Bill From Details (Company Info) - Updated with structured fields
    bill_from_company = models.CharField(max_length=200, default="Traccify", blank=True)
    bill_from_address_line1 = models.TextField(default="Trademark Sechura Thakurdwara Road, Bazar", blank=True)
    bill_from_address_line2 = models.TextField(default="Krishn, Bijnor, Uttar Pradesh, India, 246746", blank=True)
    bill_from_registration_new = models.CharField(max_length=100, default="Company Registration No: 09AMFPV3992D1ZL", blank=True)
    bill_from_msme_new = models.CharField(max_length=100, default="MSME: UP/YAM-UP-17-0028662", blank=True)
    bill_from_email = models.EmailField(default="finance@traccify.ai", blank=True)
    bill_from_gstin = models.CharField(max_length=50, default="09AMFPV3992D1ZL", blank=True)
    
    # Bill To Details (Client Info) - Add these new fields
    bill_to_company_new = models.CharField(max_length=200, default="Rohan Technology", blank=True)
    bill_to_email_new = models.EmailField(default="rohan@gmail.com", blank=True)
    bill_to_address_new = models.TextField(blank=True, null=True)
    bill_to_gstin = models.CharField(max_length=50, blank=True, null=True)

    # Financial Details - Add these new fields
    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    cgst_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    sgst_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    
    # Terms - Add these new fields
    terms_days = models.CharField(max_length=10, default="30", blank=True)
    net_terms = models.CharField(max_length=50, default="Net 30", blank=True)
    
    # Bank Details - Add these new structured fields
    bank_name = models.CharField(max_length=100, default="HDFC Bank", blank=True)
    bank_account_name = models.CharField(max_length=100, default="traccify.ai", blank=True)
    bank_account_number = models.CharField(max_length=50, default="50200094727751", blank=True)
    bank_ifsc_code = models.CharField(max_length=20, default="HDFC0007070", blank=True)
    bank_swift_code = models.CharField(max_length=20, default="HDFCINBB", blank=True)
    bank_branch_address = models.TextField(default="Ward No 12, Gr Flr, Muslim Chowdhirian, Dhampur, Hayatnagar Seohara Bijnor - 246746", blank=True)

    def calculate_gst(self):
        """Calculate GST amounts for INR invoices"""
        if self.currency == 'INR':
            base_amount = self.subtotal if self.subtotal > 0 else self.amount
            gst = base_amount * Decimal('0.18')
            cgst = base_amount * Decimal('0.09')
            sgst = base_amount * Decimal('0.09')
            return {
                'total_gst': gst.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP),
                'cgst': cgst.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP),
                'sgst': sgst.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
            }
        return {'total_gst': Decimal('0'), 'cgst': Decimal('0'), 'sgst': Decimal('0')}

    def calculate_totals(self):
        """Calculate subtotal, tax, and total from invoice lines or amount"""
        # Calculate from line items if they exist
        if hasattr(self, 'lines') and hasattr(self.lines, 'exists') and self.lines.exists():
            self.subtotal = sum(line.amount for line in self.lines.all())
        else:
            # Use the amount field if no line items
            if not self.subtotal and self.amount:
                self.subtotal = self.amount

        # Calculate tax amounts
        gst_data = self.calculate_gst()
        self.gst_amount = gst_data['total_gst']
        self.cgst_amount = gst_data['cgst'] 
        self.sgst_amount = gst_data['sgst']
        
        # Calculate total
        self.total_amount = self.subtotal + self.gst_amount

    def save(self, *args, **kwargs):
        # Auto-generate invoice number if not provided or is default
        if not self.invoice_number or self.invoice_number == 'INV-0001':
            if self.party_type == 'publisher':
                count = Invoice.objects.filter(party_type='publisher').count() + 1
                self.invoice_number = f'PUB-{count:06d}'
            else:
                count = Invoice.objects.filter(party_type='advertiser').count() + 1
                self.invoice_number = f'INV-{count:06d}'

        # Calculate totals
        self.calculate_totals()
            
        # For publisher invoices, handle tax differently
        if self.party_type == 'publisher':
            if self.currency != 'INR':
                self.gst_amount = 0
                self.cgst_amount = 0
                self.sgst_amount = 0
                self.total_amount = self.subtotal if self.subtotal > 0 else self.amount
        
        # Set default values for legacy text fields to maintain compatibility
        if not self.bill_from_details:
            self.bill_from_details = f"{self.bill_from_company}\n{self.bill_from_address_line1}\n{self.bill_from_address_line2}\n{self.bill_from_registration_new}"
        if not self.bill_to_details:
            self.bill_to_details = f"{self.bill_to_company_new}\n{self.bill_to_email_new}"
        if not self.bank_details:
            self.bank_details = f"Bank: {self.bank_name}\nName: {self.bank_account_name}\nA/C No: {self.bank_account_number}\nIFSC: {self.bank_ifsc_code}\nSWIFT: {self.bank_swift_code}"
        if not self.terms:
            self.terms = "Thanks for your business."
            
        # Clear the opposite party to ensure only one is set
        if self.party_type == 'publisher':
            self.advertiser = None
        elif self.party_type == 'advertiser':
            self.publisher = None
            
        super().save(*args, **kwargs)

    def get_display_company_name(self):
        """Get the appropriate company name for display"""
        if self.party_type == 'publisher' and self.publisher:
            return str(self.publisher)
        elif self.party_type == 'advertiser' and self.advertiser:
            return str(self.advertiser)
        return self.bill_to_company_new or "Client"

    def __str__(self):
        return f"Invoice #{self.invoice_number} - {self.get_party_type_display()}"

# New model for invoice line items
class InvoiceLine(models.Model):
    """Individual line items for an invoice"""
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name='lines')
    item_description = models.CharField(max_length=200, default="Service")
    hsn_sac = models.CharField(max_length=20, blank=True, null=True)  # HSN/SAC code for Indian tax compliance
    quantity = models.DecimalField(max_digits=10, decimal_places=2, default=1)
    rate = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    
    # Tax amounts for individual line items (useful for detailed tax reporting)
    cgst_rate = models.DecimalField(max_digits=5, decimal_places=2, default=9.00)  # CGST percentage
    sgst_rate = models.DecimalField(max_digits=5, decimal_places=2, default=9.00)  # SGST percentage
    cgst_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    sgst_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    
    # Order for display
    sort_order = models.IntegerField(default=1)
    
    def calculate_amounts(self):
        """Calculate line amounts and taxes"""
        # Basic amount calculation
        self.amount = self.quantity * self.rate
        
        # Calculate tax amounts for INR invoices
        if self.invoice and self.invoice.currency == 'INR':
            self.cgst_amount = (self.amount * self.cgst_rate / 100).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
            self.sgst_amount = (self.amount * self.sgst_rate / 100).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
        else:
            self.cgst_amount = Decimal('0')
            self.sgst_amount = Decimal('0')
    
    def save(self, *args, **kwargs):
        # Calculate amounts automatically
        self.calculate_amounts()
        super().save(*args, **kwargs)
        
        # Update invoice totals after saving line
        if self.invoice:
            try:
                self.invoice.calculate_totals()
                self.invoice.save(update_fields=['subtotal', 'gst_amount', 'cgst_amount', 'sgst_amount', 'total_amount'])
            except Exception:
                # If update_fields fails, save without specifying fields
                self.invoice.calculate_totals()
                super(Invoice, self.invoice).save()
    
    def delete(self, *args, **kwargs):
        invoice = self.invoice
        super().delete(*args, **kwargs)
        # Update invoice totals after deletion
        if invoice:
            try:
                invoice.calculate_totals()
                invoice.save(update_fields=['subtotal', 'gst_amount', 'cgst_amount', 'sgst_amount', 'total_amount'])
            except Exception:
                # If update_fields fails, save without specifying fields
                invoice.calculate_totals()
                super(Invoice, invoice).save()
    
    class Meta:
        ordering = ['sort_order', 'id']
    
    def __str__(self):
        return f"{self.item_description} - {self.amount}"

class CurrencyRate(models.Model):
    currency = models.CharField(max_length=3, unique=True)  # e.g. 'USD'
    rate_to_inr = models.DecimalField(max_digits=12, decimal_places=6)  # 1 INR = how much USD/EUR/etc
    last_updated = models.DateField(auto_now=True)

    def __str__(self):
        return f"1 INR = {self.rate_to_inr} {self.currency} (as of {self.last_updated})"