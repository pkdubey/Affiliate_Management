from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from users.decorators import role_required
from apps.advertisers.models import Advertiser
from apps.publishers.models import Publisher
from apps.offers.models import Offer
from apps.invoicing.models import Invoice
from django.db.models import Sum
from django.utils.timezone import now, timedelta
import json

# -- FULL ADMIN DASHBOARD (Admins/Subadmins Only)
@login_required
@role_required(['admin', 'subadmin'])
def dashboard_view(request):
    today = now().date()
    start_of_week = today - timedelta(days=today.weekday())
    start_of_month = today.replace(day=1)

    # --- Global Metrics ---
    total_advertisers = Advertiser.objects.count()
    total_publishers = Publisher.objects.count()
    total_offers = Offer.objects.count()
    total_invoices = Invoice.objects.count()

    # --- Revenue & Invoice Statuses ---
    invoice_status_counts = Invoice.objects.values('status').annotate(count=Sum('drs__campaign_revenue'))

    today_revenue = Invoice.objects.filter(created_at__date=today).aggregate(total=Sum('drs__campaign_revenue'))['total'] or 0
    week_revenue = Invoice.objects.filter(created_at__date__gte=start_of_week).aggregate(total=Sum('drs__campaign_revenue'))['total'] or 0
    month_revenue = Invoice.objects.filter(created_at__date__gte=start_of_month).aggregate(total=Sum('drs__campaign_revenue'))['total'] or 0

    # Ensure numbers are simple floats for templates
    today_revenue = float(today_revenue)
    week_revenue = float(week_revenue)
    month_revenue = float(month_revenue)

    # --- Graph Data (last 7 days) ---
    daily_stats = []
    for i in range(7):
        day = today - timedelta(days=i)
        day_revenue = Invoice.objects.filter(created_at__date=day).aggregate(total=Sum('drs__campaign_revenue'))['total'] or 0
        day_profit = Invoice.objects.filter(created_at__date=day).aggregate(total=Sum('drs__profit'))['total'] or 0
        daily_stats.append({'date': day.strftime('%Y-%m-%d'), 'revenue': float(day_revenue), 'profit': float(day_profit)})
    daily_stats.reverse()

    labels = [item['date'] for item in daily_stats]
    revenues = [item['revenue'] for item in daily_stats]
    profits = [item['profit'] for item in daily_stats]

    context = {
        'total_advertisers': total_advertisers,
        'total_publishers': total_publishers,
        'total_offers': total_offers,
        'total_invoices': total_invoices,
        'invoice_status_counts': invoice_status_counts,
        'today_revenue': today_revenue,
        'week_revenue': week_revenue,
        'month_revenue': month_revenue,
        'chart_labels': json.dumps(labels),
        'chart_revenues': json.dumps(revenues),
        'chart_profits': json.dumps(profits),
    }

    return render(request, 'dashboard/admin_dashboard.html', context)

# -- PUBLISHER DASHBOARD (Publisher Only)
@login_required
@role_required(['publisher'])
def publisher_dashboard(request):
    print(f"=== PUBLISHER DASHBOARD VIEW ENTERED ===")
    print(f"User: {request.user.username}")
    print(f"Role: {request.user.role}")
    
    # Check if Invoice model has a user field or publisher field
    # First, let's check what fields are available on the Invoice model
    invoice_fields = [f.name for f in Invoice._meta.get_fields()]
    print(f"Invoice model fields: {invoice_fields}")
    
    # Try to filter by user first, then by publisher if user field doesn't exist
    user = request.user
    
    # Check if Invoice has a 'user' field
    if 'user' in invoice_fields:
        print("Using 'user' field for filtering")
        invoice_filter = {'user': user}
    # Check if Invoice has a 'publisher' field (but user doesn't have publisher attribute)
    elif 'publisher' in invoice_fields:
        print("Using 'publisher' field for filtering but user has no publisher attribute")
        # Since user doesn't have publisher attribute, we need to find another way
        # For now, return empty data or handle this case
        return render(request, 'dashboard/publisher_dashboard.html', {
            'total_income': 0,
            'total_invoices': 0,
            'chart_labels': json.dumps([]),
            'chart_revenues': json.dumps([]),
            'chart_profits': json.dumps([]),
            'error_message': 'Publisher profile not properly configured'
        })
    else:
        print("No user or publisher field found in Invoice model")
        return render(request, 'dashboard/publisher_dashboard.html', {
            'total_income': 0,
            'total_invoices': 0,
            'chart_labels': json.dumps([]),
            'chart_revenues': json.dumps([]),
            'chart_profits': json.dumps([]),
            'error_message': 'Invoice model configuration error'
        })
    
    # Only show user's own income and relevant invoice stats
    total_income = Invoice.objects.filter(**invoice_filter).aggregate(
        total=Sum('drs__campaign_revenue')
    )['total'] or 0
    total_income = float(total_income)

    total_invoices = Invoice.objects.filter(**invoice_filter).count()

    # Optionally show user's own daily revenue chart
    today = now().date()
    daily_stats = []
    for i in range(7):
        day = today - timedelta(days=i)
        day_filter = invoice_filter.copy()
        day_filter['created_at__date'] = day
        
        day_revenue = Invoice.objects.filter(**day_filter).aggregate(
            total=Sum('drs__campaign_revenue')
        )['total'] or 0
        day_profit = Invoice.objects.filter(**day_filter).aggregate(
            total=Sum('drs__profit')
        )['total'] or 0
        daily_stats.append({'date': day.strftime('%Y-%m-%d'), 'revenue': float(day_revenue), 'profit': float(day_profit)})
    daily_stats.reverse()

    labels = [item['date'] for item in daily_stats]
    revenues = [item['revenue'] for item in daily_stats]
    profits = [item['profit'] for item in daily_stats]

    context = {
        'total_income': total_income,
        'total_invoices': total_invoices,
        'chart_labels': json.dumps(labels),
        'chart_revenues': json.dumps(revenues),
        'chart_profits': json.dumps(profits),
    }

    return render(request, 'dashboard/publisher_dashboard.html', context)

def default_dashboard(request):
    return render(request, "dashboard/default_dashboard.html")

def debug_user(request):
    return render(request, 'debug_user.html')

# -- LOGIN SUCCESS REDIRECT
def login_success(request):
    user = request.user
    if user.is_superuser:
        return redirect('dashboard:admin_dashboard')
    elif user.role in ['admin', 'subadmin', 'dashboard']:  # Added 'dashboard' role
        return redirect('dashboard:admin_dashboard')
    elif user.role == 'publisher':
        return redirect('dashboard:publisher_dashboard')
    else:
        return redirect('dashboard:default_dashboard')