from django import forms
from .models import Invoice

class InvoiceForm(forms.ModelForm):
    # Manually add a date field for editing if required
    date = forms.DateField(required=True, widget=forms.DateInput(attrs={'type': 'date'}))
    
    class Meta:
        model = Invoice
        exclude = ['created_at', 'updated_at']  # exclude non-editable fields; do NOT include 'date'
        widgets = {
            'gst_amount': forms.NumberInput(attrs={'step': '0.01'}),
            'total_amount': forms.NumberInput(attrs={'step': '0.01'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Optional: initialize date from instance if available
        if self.instance and self.instance.pk and self.instance.date:
            self.fields['date'].initial = self.instance.date
        
        # Your existing __init__ logic continues here...
        self.fields['drs'].required = False
        self.fields['gst_amount'].required = False
        self.fields['total_amount'].required = False
        self.fields['bill_from_details'].required = False
        self.fields['bill_to_details'].required = False
        self.fields['bank_details'].required = False
        self.fields['terms'].required = False
        
        if self.data.get('party_type') == 'publisher':
            self.fields['advertiser'].required = False
            self.fields['publisher'].required = True
            self.fields['pdf'].required = True
        elif self.data.get('party_type') == 'advertiser':
            self.fields['publisher'].required = False
            self.fields['pdf'].required = False
            self.fields['advertiser'].required = True

    def clean(self):
        cleaned_data = super().clean()
        party_type = cleaned_data.get('party_type')
        
        if party_type == 'publisher':
            if not cleaned_data.get('publisher'):
                raise forms.ValidationError('Publisher is required for publisher invoices.')
            if not cleaned_data.get('pdf') and not self.instance.pdf:
                raise forms.ValidationError('Invoice PDF/Image is required for publisher invoices.')
        elif party_type == 'advertiser':
            if not cleaned_data.get('advertiser'):
                raise forms.ValidationError('Advertiser is required for advertiser invoices.')
        return cleaned_data
