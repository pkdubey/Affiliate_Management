from django.urls import path
from . import views

app_name = 'dashboard'

urlpatterns = [
    path('admin/', views.dashboard_view, name='admin_dashboard'),
    path('publisher/', views.publisher_dashboard, name='publisher_dashboard'),
    path('default/', views.default_dashboard, name='default_dashboard'),
    path('debug/', views.debug_user, name='debug_user'),
]